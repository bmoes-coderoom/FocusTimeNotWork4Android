export const colors = {
  white: '#fff',
  darkBlue: '#252250',
  progressBar: '#5E84E2',
};